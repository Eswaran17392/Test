﻿using FormsCustomControl;
using FormsCustomControl.UWP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Xamarin.Forms;
using Xamarin.Forms.Platform.UWP;
using Windows.UI.Xaml.Automation.Peers;

[assembly: ExportRenderer(typeof(FormsCustomLayout), typeof(FormsCustomLayoutRenderer))]
namespace FormsCustomControl.UWP
{
    class FormsCustomLayoutRenderer : ViewRenderer<FormsCustomLayout, FrameworkElement>
    {
        private FormsCustomLayout inputLayout;

        /// <summary>
        /// Gets or sets the <see cref="TextBox.Text"/>.
        /// </summary>
        internal string Text
        {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }

        /// <summary>
        /// Gets or sets the <see cref="TextBox.Text"/>.
        /// </summary>
        internal static readonly DependencyProperty TextProperty =
            DependencyProperty.Register("Text", typeof(string), typeof(FormsCustomLayoutRenderer), new PropertyMetadata(null, OnTextPropertyChanged));

        private static void OnTextPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            (d as FormsCustomLayoutRenderer).OnTextPropertyChanged();
        }

        /// <summary>
        /// Occurred when <see cref="Text"/> property changed.
        /// </summary>
        private void OnTextPropertyChanged()
        {
            inputLayout?.UpdateText(this.Text);
        }


        /// <summary>
        /// Specifies the panel.
        /// </summary>
        private Panel inputViewRenderer;


        /// <summary>
        /// Gets or sets the <see cref="TextBox"/>.
        /// </summary>
        private TextBox nativeTextBox;

        /// <summary>
        /// Method that is called when the automation id is set.
        /// </summary>
        /// <param name="id">The automation id.</param>
        protected override void SetAutomationId(string id)
        {
            if (this.Control == null)
            {
                base.SetAutomationId(id);
            }
            else
            {
                this.SetAutomationPropertiesAutomationId(id);
                this.Control.SetAutomationPropertiesAutomationId(id);
            }
        }

        /// <summary>
        /// Provide automation peer for the control
        /// </summary>
        /// <returns>The TextInputLayout view automation peer.</returns>
        protected override AutomationPeer OnCreateAutomationPeer()
        {
            if (this.Control == null)
            {
                return new FormsCustomLayoutAutomationPeer(this);
            }

            return new FormsCustomLayoutAutomationPeer(this.Control);
        }

        protected override void OnElementChanged(ElementChangedEventArgs<FormsCustomLayout> e)
        {
            base.OnElementChanged(e);
            var element = e.NewElement;
            if (element != null && element is FormsCustomLayout)
            {
                //if (!string.IsNullOrEmpty(Element?.AutomationId))
                //{
                //    SetValue(Windows.UI.Xaml.Automation.AutomationProperties.AutomationIdProperty, Element.AutomationId);
                //}

                inputLayout = element as FormsCustomLayout;
                UpdateNativeView(inputLayout.InputView);
            }
            // setting Dummy native control.
           // SetNativeControl(new Grid());
        }

        private void UpdateNativeView(View inputView)
        {
            if (inputView == null)
            {
                return;
            }

            if (Platform.GetRenderer(inputView) == null)
            {
                Platform.SetRenderer(inputView, Platform.CreateRenderer(inputView));
            }

            var renderer = Platform.GetRenderer(inputView);
            inputViewRenderer = renderer as Panel;
            nativeTextBox = GetNativeTextBox(inputViewRenderer);
            if (nativeTextBox is FormsTextBox)
            {
                (nativeTextBox as FormsTextBox).BackgroundFocusBrush = new Windows.UI.Xaml.Media.SolidColorBrush(Colors.Transparent);
            }

            if (nativeTextBox is TextBox)
            {
                if (nativeTextBox != null)
                {
                    nativeTextBox.IsTabStop = inputLayout.IsEnabled;
                    SetBinding(TextProperty, new Windows.UI.Xaml.Data.Binding { Source = nativeTextBox, Path = new PropertyPath("Text"), Mode = Windows.UI.Xaml.Data.BindingMode.TwoWay });
                }
            }

            Loaded += OnLoaded;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            if (nativeTextBox == null)
            {
                return;
            }
        }

        private TextBox GetNativeTextBox(FrameworkElement frameworkElement)
        {
            TextBox textBox = null;
            int childCount = VisualTreeHelper.GetChildrenCount(frameworkElement);
            for (int i = 0; i < childCount; i++)
            {
                var child = VisualTreeHelper.GetChild(frameworkElement, i);
                if (child is TextBox)
                {
                    textBox = child as TextBox;
                }
                else if (child is FrameworkElement innerElement)
                {
                    textBox = GetNativeTextBox(innerElement);
                }

                if (textBox != null)
                {
                    break;
                }
            }

            return textBox;
        }

        /// <summary>
        /// Initialize the <see cref="FormsCustomLayoutRenderer"/> when it was called.
        /// </summary>
        public static void Init()
        {
        }
    }

    internal class FormsCustomLayoutAutomationPeer : FrameworkElementAutomationPeer
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FormsCustomLayoutRenderer"/> class.
        /// </summary>
        /// <param name="owner">FormsCustomLayout View control</param>
        public FormsCustomLayoutAutomationPeer(FrameworkElement owner) : base(owner)
        {
        }

        /// <summary>
        /// Describe the control type
        /// </summary>
        /// <returns>The control type.</returns>
        protected override AutomationControlType GetAutomationControlTypeCore()
        {
            return AutomationControlType.Custom;
        }

        /// <summary>
        /// Describe the class name.
        /// </summary>
        /// <returns>The Class Name.</returns>
        protected override string GetClassNameCore()
        {
            return "FormsCustomLayout";
        }
    }
}
