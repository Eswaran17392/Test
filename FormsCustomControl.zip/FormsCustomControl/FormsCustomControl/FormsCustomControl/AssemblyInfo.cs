using System.Runtime.CompilerServices;
using Xamarin.Forms.Xaml;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]

[assembly: InternalsVisibleTo("FormsCustomControl.UWP")]